export default [
  { id: '123', name: 'foo' },
  { id: '2345', name: 'bar' },
  { id: '4444', name: 'geadfa' }
]
