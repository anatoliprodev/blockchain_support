const { Harmony } = require('@harmony-js/core')
const { ChainID, ChainType } = require('@harmony-js/utils')
const {
  SubscribeBlockTracker,
  SubscriptionMethod
} = require('@harmony-js/network')

const yargs = require('yargs')

const ganache = require('ganache-cli')

const port = 18545

const url = `http://localhost:${port}`

const wsUrl = `ws://localhost:${port}`

const mne =
  'food response winner warfare indicate visual hundred toilet jealous okay relief tornado'

console.log('--- hint: please write these down')
console.log('-------------------------------------')
console.log(`${mne}`)
console.log('-------------------------------------')

// we use ChainType='hmy' to indicate we are using `harmony node`
// if we set it to 'eth', we use `eth` as our settings.
// here 'eth' is used, which means we use ethereum-node.

console.log(ChainType)

const harmony = new Harmony(wsUrl, {
  chainType: ChainType.Ethereum,
  chainId: ChainID.Geth
})

const wsHarmony = new Harmony(wsUrl, {
  chainType: ChainType.Ethereum,
  chainId: ChainID.Geth
})

async function createAndEncrypt(words, index, password) {
  for (let i = 0; i < index; i++) {
    const newAcc = harmony.wallet.addByMnemonic(words, i)
    await harmony.wallet.encryptAccount(newAcc.address, password)
  }
}

const acc = harmony.wallet.addByMnemonic(mne, 0)

console.log('--- hint: we use this private key to test with ganache')
console.log('-------------------------------------')
console.log(`${acc.privateKey}`)
console.log('-------------------------------------')

const hexBalance = harmony.utils.numberToHex(
  new harmony.utils.Unit('10000').asEther().toWei()
)
console.log({ hexBalance })

const server = ganache.server({
  accounts: [
    {
      secretKey: acc.privateKey,
      balance: hexBalance
    }
  ],
  default_balance_ether: 10000,
  gasLimit: '0x3000000',
  allowUnlimitedContractSize: true
})

// now it is async time

async function main() {
  const password = '1234567890123'

  await createAndEncrypt(mne, 10, password)

  // harmony.blockchain.newPendingTransacitons();

  const latestBalance = await harmony.blockchain.getBalance({
    address: acc.address,
    blockNumber: 'latest'
  })
  console.log('--- testing: hmy_getBalance')
  console.log('-------------------------------------')
  console.log({ balance: harmony.utils.hexToNumber(latestBalance.result) })
  console.log('-------------------------------------')

  const nonce = await harmony.blockchain.getTransactionCount({
    address: harmony.wallet.signer.address,
    blockNumber: 'latest'
  })
  console.log('--- testing: hmy_getTransactionCount')
  console.log('-------------------------------------')
  console.log({
    nonce: Number.parseInt(harmony.utils.hexToNumber(nonce.result), 10)
  })
  console.log('-------------------------------------')

  const balanceOfAccount = await harmony.wallet.signer.getBalance()

  console.log('--- testing: Account.getBalance')
  console.log('-------------------------------------')
  console.log(balanceOfAccount)
  console.log('-------------------------------------')

  const sendTo = '0xccaed3f53bd0a55db215cc58182969e59d2242fe'

  const txn = harmony.transactions.newTx({
    to: harmony.crypto.getAddress(sendTo).checksum,
    value: new harmony.utils.Unit('1234567').asWei().toWei(),
    gasLimit: new harmony.utils.Unit('21000').asWei().toWei(),
    gasPrice: new harmony.utils.Unit('100000000000').asWei().toWei()
  })

  // now we sign and send a transaction

  const signed = await harmony.wallet.signTransaction(txn, undefined, password)

  console.log('--- testing: Account.signTransaction')
  console.log('-------------------------------------')
  console.log({ signedTransactionPayload: signed.txPayload })
  console.log('-------------------------------------')

  const [sentTxn, TranID] = await signed.sendTransaction()

  console.log('--- testing: Transaction.sendTransaction')
  console.log('-------------------------------------')
  console.log({ TranID })
  console.log('-------------------------------------')

  const confirmed = await sentTxn.confirm(TranID, 20, 1000)

  console.log('--- testing: Transaction.confirm')
  console.log('-------------------------------------')
  console.log({
    confirmed: confirmed.isConfirmed(),
    receipt: confirmed.receipt
  })
  console.log('-------------------------------------')

  const latestBlock = await harmony.blockchain.getBlockByNumber({
    blockNumber: 'latest'
  })
  console.log('--- testing: hmy_getBlockByNumber')
  console.log('-------------------------------------')
  console.log({ latestBlockHash: latestBlock.result.hash })
  console.log('-------------------------------------')

  const sameLatestBlock = await harmony.blockchain.getBlockByHash({
    blockHash: latestBlock.result.hash
  })
  console.log('--- testing: hmy_getBlockByHash')
  console.log('-------------------------------------')
  console.log({ sameLatestBlockNumber: sameLatestBlock.result.number })
  console.log('-------------------------------------')

  const blockTransactionCount = await harmony.blockchain.getBlockTransactionCountByHash(
    {
      blockHash: latestBlock.result.hash
    }
  )
  console.log('--- testing: hmy_getBlockTransactionCountByHash')
  console.log('-------------------------------------')
  console.log(blockTransactionCount.result)
  console.log('-------------------------------------')

  const sameBlockTransactionCount = await harmony.blockchain.getBlockTransactionCountByNumber(
    {
      blockNumber: latestBlock.result.number
    }
  )
  console.log('--- testing: hmy_getBlockTransactionCountByNumber')
  console.log('-------------------------------------')
  console.log(sameBlockTransactionCount.result)
  console.log('-------------------------------------')

  const transaction = await harmony.blockchain.getTransactionByBlockHashAndIndex(
    {
      blockHash: latestBlock.result.hash,
      index: '0x0'
    }
  )
  console.log('--- testing: hmy_getTransactionByBlockHashAndIndex')
  console.log('-------------------------------------')
  console.log(transaction.result)
  console.log('-------------------------------------')

  const sameTransaction = await harmony.blockchain.getTransactionByBlockNumberAndIndex(
    {
      blockNumber: latestBlock.result.number,
      index: '0x0'
    }
  )
  console.log('--- testing: hmy_getTransactionByBlockNumberAndIndex')
  console.log('-------------------------------------')
  console.log({ gas: sameTransaction.result.gas })
  console.log('-------------------------------------')

  const sameTransaction2 = await harmony.blockchain.getTransactionByHash({
    txnHash: transaction.result.hash
  })
  const { gas, gasPrice, value } = sameTransaction2.result
  const valueBN = harmony.utils.hexToBN(value)
  const gasBN = harmony.utils.hexToBN(gas)
  const gasPriceBN = harmony.utils.hexToBN(gasPrice)
  const actualCost = new harmony.utils.Unit(gasBN.mul(gasPriceBN).add(valueBN))
    .asWei()
    .toWei()
  console.log('--- testing: hmy_getTransactionByHash')
  console.log('-------------------------------------')
  console.log({
    actualCost: actualCost.toString(),
    gas: harmony.utils.hexToNumber(gas),
    gasPrice: gasPriceBN.toString(),
    value: valueBN.toString(),
    comment: 'actualCost= gas * gasPrice + value'
  })
  console.log('-------------------------------------')

  const getBalanceAgainObject = await harmony.wallet.signer.getBalance()
  console.log('--- testing: get balance again')
  console.log('-------------------------------------')
  console.log(getBalanceAgainObject)
  console.log('-------------------------------------')

  setTimeout(async () => {
    const txn2 = harmony.transactions.clone(txn)
    const s2 = await harmony.wallet.signTransaction(txn2, undefined, password)
    const [sentTxn, TranID] = await s2.sendTransaction()
    await sentTxn.confirm(TranID, 20, 1000)
    console.log({
      id: sentTxn.id,
      blockNumbers: sentTxn.blockNumbers,
      txStatus: sentTxn.txStatus,
      confirmations: sentTxn.confirmations,
      confirmationCheck: sentTxn.confirmationCheck
    })
  }, 5000)

  setTimeout(async () => {
    const txn3 = harmony.transactions.clone(txn)
    const s3 = await harmony.wallet.signTransaction(txn3, undefined, password)
    const [sentTxn, TranID] = await s3.sendTransaction()
    await sentTxn.confirm(TranID, 20, 1000)
    console.log({
      id: sentTxn.id,
      blockNumbers: sentTxn.blockNumbers,
      txStatus: sentTxn.txStatus,
      confirmations: sentTxn.confirmations,
      confirmationCheck: sentTxn.confirmationCheck
    })
  }, 10000)
  setTimeout(async () => {
    const txns3 = harmony.transactions.clone(txn)
    const s3 = await harmony.wallet.signTransaction(txns3, undefined, password)
    const [sentTxn, TranID] = await s3.sendTransaction()
    await sentTxn.confirm(TranID, 20, 1000)
    console.log({
      id: sentTxn.id,
      blockNumbers: sentTxn.blockNumbers,
      txStatus: sentTxn.txStatus,
      confirmations: sentTxn.confirmations,
      confirmationCheck: sentTxn.confirmationCheck
    })
  }, 15000)
  setTimeout(async () => {
    const txn4 = harmony.transactions.clone(txn)
    const s4 = await harmony.wallet.signTransaction(txn4, undefined, password)
    const [sentTxn, TranID] = await s4.sendTransaction()
    await sentTxn.confirm(TranID, 20, 1000)
    console.log({
      id: sentTxn.id,
      blockNumbers: sentTxn.blockNumbers,
      txStatus: sentTxn.txStatus,
      confirmations: sentTxn.confirmations,
      confirmationCheck: sentTxn.confirmationCheck
    })
  }, 20000)
  setTimeout(async () => {
    const txn5 = harmony.transactions.clone(txn)
    const s5 = await harmony.wallet.signTransaction(txn5, undefined, password)
    const [sentTxn, TranID] = await s5.sendTransaction()
    await sentTxn.confirm(TranID, 20, 1000)
    console.log({
      id: sentTxn.id,
      blockNumbers: sentTxn.blockNumbers,
      txStatus: sentTxn.txStatus,
      confirmations: sentTxn.confirmations,
      confirmationCheck: sentTxn.confirmationCheck
    })
  }, 25000)
  setTimeout(async () => {
    const txn6 = harmony.transactions.clone(txn)
    const s6 = await harmony.wallet.signTransaction(txn6, undefined, password)
    const [sentTxn, TranID] = await s6.sendTransaction()
    await sentTxn.confirm(TranID, 20, 1000)
    console.log({
      id: sentTxn.id,
      blockNumbers: sentTxn.blockNumbers,
      txStatus: sentTxn.txStatus,
      confirmations: sentTxn.confirmations,
      confirmationCheck: sentTxn.confirmationCheck
    })
  }, 30000)
  setTimeout(async () => {
    process.exit()
  }, 30000)
}

if (process.argv0 !== undefined) {
  const argv = yargs.alias('d', 'debug').describe('d', 'debug mode').argv

  const debug = argv.debug

  if (debug) {
    server.listen(port, function(err, blockchain) {})
  } else {
    server.listen(port, function(err, blockchain) {
      main()
    })
  }
}
