import { Harmony } from '@harmony-js/core';

const harmony = new Harmony();

export { harmony };
