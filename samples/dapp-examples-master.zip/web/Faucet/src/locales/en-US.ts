export default {
  'index.start': 'Getting Started',
}
