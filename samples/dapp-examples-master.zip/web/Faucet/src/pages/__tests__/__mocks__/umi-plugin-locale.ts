export const formatMessage = (): string => 'Mock text';
