firebase deploy --only functions
