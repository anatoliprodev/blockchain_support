curl 'http://localhost:5000/newpuzzle-35360/us-central1/payout?address=0xf48e01968079d7ff6e1ea70bfe71afa1868b7dab&id=ZnyX5nqC9PmnqSIASnRv&level=11&sequence=LRUD'
