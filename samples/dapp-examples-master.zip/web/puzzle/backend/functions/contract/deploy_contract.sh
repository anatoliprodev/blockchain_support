snode deploy.js -f ./contracts/puzzle/Puzzle.sol -l 840000 -p 100
