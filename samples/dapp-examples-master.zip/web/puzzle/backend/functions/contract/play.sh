curl 'http://localhost:5000/newpuzzle-35360/us-central1/play'
