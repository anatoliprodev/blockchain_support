curl -X POST 'https://us-central1-newpuzzle-35360.cloudfunctions.net/payout?address=0x4dcb7672b9bf6955c767fa9170ca29690d54eefd&id=Wds2Jo4Dx5Ze4BeAafWC&level=11&sequence=LRUD' -d "Content-Length: 0"
