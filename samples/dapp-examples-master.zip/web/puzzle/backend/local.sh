firebase serve --only functions
