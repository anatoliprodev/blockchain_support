echo "I assumed you already built (npm run build) before this pushing"
firebase deploy --only hosting:harmony-puzzle
