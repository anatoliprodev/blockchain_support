# Tutorial Fixture

This does basically what the tutorial does

## Development

Run two terminal tabs

```sh
# remix run2
yarn dev

# remix-serve
yarn start
```

This uses the new built-in `remix-serve` express server that purges the app build require cache and doesn't require restarts.
