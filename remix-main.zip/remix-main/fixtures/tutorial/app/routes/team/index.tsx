export default function TeamIndex() {
  return (
    <div>
      <h3>Team</h3>
      <p>
        Here we could show cool stats about the team or recent activity, etc.
      </p>
    </div>
  );
}
