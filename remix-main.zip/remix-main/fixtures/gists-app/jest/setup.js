// Puppeteer is slow, so we need to wait for it sometimes.
jest.setTimeout(10000);
