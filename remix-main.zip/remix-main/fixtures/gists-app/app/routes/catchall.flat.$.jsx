export default function Comp() {
  return <div data-test-id="/catchall/flat">Catchall flat</div>;
}
