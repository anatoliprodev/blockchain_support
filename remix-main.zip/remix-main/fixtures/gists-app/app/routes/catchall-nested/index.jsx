export default function CatchAllIndex() {
  return <h1 data-test-id="/catchall-nested/index">Index</h1>;
}
