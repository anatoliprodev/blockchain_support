export default function Comp() {
  return <div data-test-id="/catchall-nested/splat">Catchall Nested</div>;
}
