export default function WithLayout() {
  return (
    <div>
      <h1>Page inside layout</h1>
    </div>
  );
}
