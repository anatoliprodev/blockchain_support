export default function Comp() {
  return <div data-test-id="/catchall-nested-no-layout">Catchall Nested</div>;
}
