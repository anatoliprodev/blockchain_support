// this file should be ignored by Remix
export default {};
