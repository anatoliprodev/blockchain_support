export default function Gists() {
  return (
    <div data-test-id="/gists/mine">
      <h1>My Gists</h1>
    </div>
  );
}
