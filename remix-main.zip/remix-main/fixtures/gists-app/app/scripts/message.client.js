export const message = "I'm on the client";
