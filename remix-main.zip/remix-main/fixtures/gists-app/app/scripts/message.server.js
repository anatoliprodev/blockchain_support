export const message = "I'm on the server";
