export default function Shared() {
  return (
    <div>
      <p>Shared</p>
    </div>
  );
}
