export default function Page() {
  return <p>This is page four</p>;
}
