module.exports = {
  purge: ["./app/**/*.{js,jsx,ts,tsx}"],
  darkMode: false,
  theme: {
    extend: {}
  },
  variants: {},
  plugins: []
};
