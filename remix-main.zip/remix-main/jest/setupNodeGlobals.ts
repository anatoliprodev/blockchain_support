import { installGlobals } from "../packages/remix-node/globals";

installGlobals();
