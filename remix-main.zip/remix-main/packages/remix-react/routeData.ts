import type { AppData } from "./data";

export interface RouteData {
  [routeId: string]: AppData;
}
