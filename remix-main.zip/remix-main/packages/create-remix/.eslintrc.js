module.exports = {
  rules: {
    // we have an example where we need this
    "no-undef": "off"
  }
};
