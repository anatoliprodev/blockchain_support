module.exports = {
  rules: {
    "prefer-const": "warn",

    // because in our templates we shouldn't care
    "import/order": "off"
  }
};
