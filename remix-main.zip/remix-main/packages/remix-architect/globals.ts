import { installGlobals } from "@remix-run/node";
installGlobals();
