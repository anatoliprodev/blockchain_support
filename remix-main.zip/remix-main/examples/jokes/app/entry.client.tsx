import ReactDOM from "react-dom";
import { RemixBrowser } from "remix";

ReactDOM.hydrate(<RemixBrowser />, document);
