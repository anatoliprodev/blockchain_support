module.exports = {
  rules: {
    "prefer-const": "warn",

    // because in our examples we shouldn't care
    "import/order": "off"
  }
};
