// Sometimes some modules don't work in the browser, Remix will generally be
// able to remove server-only code automatically as long as you don't improt it
// directly from a route module (that's where the automatic removal happens). If
// you're ever still having trouble, you can skip the remix remove-server-code
// magic and drop your code into a file that ends with `.server` like this one.
// Remix won't even try to figure things out on its own, it'll just completely
// ignore it for the browser bundles. On a related note, crypto can't be
// imported directly into a route module, but if it's in this file you're fine.
import { createHash } from "crypto";

export function hash(str: string) {
  return createHash("sha1").update(str).digest("hex").toString();
}
