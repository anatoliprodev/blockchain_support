export default function ClientIndexRoute() {
  return <div>Please select a client</div>;
}
