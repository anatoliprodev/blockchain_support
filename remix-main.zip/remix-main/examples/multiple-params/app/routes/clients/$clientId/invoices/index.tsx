export default function ClientInvoiceIndexRoute() {
  return <div>Please select an invoice</div>;
}
