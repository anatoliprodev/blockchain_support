export default function IndexRoute() {
  return (
    <div>
      <h1>Hello from the Index Route</h1>
    </div>
  );
}
