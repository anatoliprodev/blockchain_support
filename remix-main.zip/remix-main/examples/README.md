# Remix Examples

Welcome to the examples for Remix.

Here you'll find various examples of using Remix to accomplish certain tasks. Each example is a complete application including a build and even a button to preview a live instance of the app so you can play with it.

Also, remember to check out the README!

Enjoy!
